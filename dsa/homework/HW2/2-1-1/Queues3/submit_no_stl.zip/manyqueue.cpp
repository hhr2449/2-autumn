#include "manyqueue.h"

QueueManager::QueueManager(unsigned int m) {
    queues = new Queue[m + 1];  // 队列编号从1开始，所以分配m+1个
    size = m;
}

QueueManager::~QueueManager() {
    delete[] queues;  // 释放队列数组的内存
}

void QueueManager::push(unsigned int k, unsigned int x) {
    if (k >= 1 && k <= size) {
        queues[k].qpush(x);
    }
}

void QueueManager::pop(unsigned int k) {
    if (k >= 1 && k <= size) {
        queues[k].qpop();
    }
}

unsigned int QueueManager::query(unsigned int k, unsigned int i) {
    if (k >= 1 && k <= size) {
        return queues[k].query(i);
    }
    return 0;  // 如果k超出范围，返回0
}
